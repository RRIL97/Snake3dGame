#pragma once
#include "igl/opengl/glfw/Viewer.h"
#include "igl/opengl/ViewerData.h"
#include "igl/opengl/ViewerCore.h"
#include <time.h>
#include "sandBox.h"
#include "snake.h"
#include "backgroundHandler.h"
class GameMenu;
class ObjectManager;
enum class GameState { PLAY, PAUSED, MENU };
class Game : public SandBox {
public:
	Game(igl::opengl::glfw::imgui::ImGuiMenu* menu);
	~Game();
	void initMenu();
	void initGame();
	void gameLoop();
	GameState getGameState() { return gameState; }
	void setGameState(GameState state) { gameState = state; }
	void increaseLevel() { level++; }
	Snake* getSnake() { return snake; }
	float getProgress() {return score / maxScore;}
	float getHealth() { return health / maxHealth; }
	void increaseProgress();
	void increaseHealth();
	void decreaseHealth();
	GameMenu* getGameMenu() { return gameMenu; }
	int getTick() { return tick; }
	int getMeshIdCollision() { return meshIdCollision; }
	void resetMeshIdCollision() { meshIdCollision = -1; }
	void Animate();
	bool shouldMoveSanke;

private:
	ObjectManager* objectManager;
	GameState gameState;
	GameMenu* gameMenu;
	backgroundHandler* back;
	Snake* snake;
	int level;
	float score;
	float health;
	float maxHealth;
	float maxScore;
	int tick;
	int meshIdCollision;
};