#include "SoundManager.h"

SoundManager::SoundManager() {
	engine = createIrrKlangDevice();

	if (!engine)
		return;
}
void SoundManager::playHoverMenuSound() {
	engine->play2D("C:\\Users\\Coder\\Desktop\\LastProject\\Hover.mp3", true);
}
void SoundManager::playGameSound() {
	engine->play2D("C:\\Users\\Coder\\Desktop\\LastProject\\Game.mp3", true);
}
