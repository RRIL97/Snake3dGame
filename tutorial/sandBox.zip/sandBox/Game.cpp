#include "Game.h"
#include "igl/opengl/glfw/Viewer.h"
#include "igl/opengl/ViewerData.h"
#include <time.h>
#include "sandBox.h"
#include "snake.h"
#include "GameMenu.h"
#include "ObjectManager.h"
#include "backgroundHandler.h"


Game::Game(igl::opengl::glfw::imgui::ImGuiMenu* menu) :level(0),score(0.0),maxScore(100.0), health(100.0), maxHealth(100.0),tick(0), meshIdCollision(-1), shouldMoveSanke(false){
	 snake         = new Snake             (this, 16);
	 back          = new backgroundHandler (this);
	 gameMenu      = new GameMenu          (this,menu);
	 objectManager = new ObjectManager     (this);

	 gameState     = GameState::MENU; 
	 direction     = Eigen::Vector3d(0, 0, 0.0005);

	 initGame();

}
void Game::initGame() {
	std::cout << "Current Level : "<< level << std::endl;
	if (level == 0) { 
		std::cout << "Initated Snake & Background (Level 0)" << std::endl;
		snake->initSnake("configuration.txt");
		//back->initBackground();
		//objectManager->addHealthObject();
	}
	else if (level == 1) {
		health   = 100;
		score    = 0;
		std::cout << "Level1 Initated.. " << std::endl;
		objectManager->addHealthObjects(1);
		//objectManager->addScoreObjects(3);
	   // objectManager->addMovingObstacles(3);
	}
}

Game::~Game(){
	delete gameMenu;
	delete back;
	delete snake;
}

void Game::initMenu(){
	gameMenu->init();
}

void Game::gameLoop(){
	tick++;
	objectManager->updateObjects();
	if (shouldMoveSanke)
		snake->skinnig(direction);
	
	int size = data_list.size();
	for (int i = 17; i < size; i++) {
		if (thereIsCollision(&trees[0], &trees[i],  0 , i)) {
    	 	meshIdCollision = i;
		    std::cout << "Collision!!!!!  " << meshIdCollision << std::endl;
			break; 
		}
		else {
			//std::cout << "No Collision!" << std::endl;;
		}
	}
}
void Game::Animate() {
     gameLoop();
}
void Game::increaseProgress(){
	std::cout << "increaseProgress() called, Decreasing Score Remaining!" << std::endl;
	score += 10.0;
}
void Game::increaseHealth()
{
	std::cout << "increaseHealth() Called" << std::endl; 
	if (health <100)
	health += 10.0; 
}
void Game::decreaseHealth()
{
	std::cout << "decreaseHealth() Called" << std::endl; 
	if(health>0)
	health -= 10.0;
}
