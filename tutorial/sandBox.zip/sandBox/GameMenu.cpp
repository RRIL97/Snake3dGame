#include "GameMenu.h"
#include "Game.h"
#include <igl/opengl/ViewerCore.h>

#include <igl/opengl/glfw/imgui/ImGuiMenu.h>
#include <igl/opengl/glfw/imgui/ImGuiHelpers.h>

GameMenu::GameMenu(Game* game, igl::opengl::glfw::imgui::ImGuiMenu* menu) {
	this->game = game;
	this->menu = menu;
 
}
void GameMenu::init(){
}
void GameMenu::startGameMenu(std::vector<igl::opengl::ViewerCore>& core) { 
		int imageWidth = 0;
		int imageHeight = 0;
		
		ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiSetCond_FirstUseEver);
		ImGui::SetNextWindowSize(ImVec2(300, 800), ImGuiSetCond_FirstUseEver);
		ImGui::SetNextWindowSizeConstraints(ImVec2(325, -1.0f), ImVec2(325, -1.0f));

		ImGui::Begin("Snake Game - Animation Class", nullptr,  ImGuiWindowFlags_NoMove);
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::InputText("Name", characterName, IM_ARRAYSIZE(characterName));
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();
		if (ImGui::Button("Start", ImVec2(-1, 0)))
		{
			game->increaseLevel();
			game->initGame();
			game->setGameState(GameState::PLAY);
		}
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();
		if (ImGui::Button("Stop", ImVec2(-1, 0)))
		{
			game->setGameState(GameState::PAUSED);
		}
		ImGui::Spacing();
		ImGui::Spacing();
		ImGui::Spacing();

		ImGui::BulletText("Snake Game By Sabina & Ron Rachev\nAnimation Class\n");
		ImGui::End();
	
}

void GameMenu::startGameMenuPaused(std::vector<igl::opengl::ViewerCore>& core)
{
	int imageWidth = 0;
	int imageHeight = 0;
	
	ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiSetCond_FirstUseEver);
	ImGui::SetNextWindowSize(ImVec2(300, 800), ImGuiSetCond_FirstUseEver);
	
	ImGui::SetNextWindowSizeConstraints(ImVec2(325, -1.0f), ImVec2(325, -1.0f));

	ImGui::Begin("Snake Game - Animation Class", nullptr,  ImGuiWindowFlags_NoMove);
	ImGui::Text(characterName);
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::ProgressBar(game->getProgress(), ImVec2(0.0f, 0.0f));
	ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
	ImGui::Text("Progress Bar");
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::ProgressBar(game->getHealth(), ImVec2(0.0f, 0.0f));
	ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
	ImGui::Text("Health Bar");
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();

	if (ImGui::Button("Continue", ImVec2(-1, 0)))
	{
		game->setGameState(GameState::PLAY);
	}
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	if (ImGui::Button("Back to menu", ImVec2(-1, 0)))
	{
		game->setGameState(GameState::MENU);
	}
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();

	ImGui::BulletText("Snake Game By Sabina & Ron Rachev\nAnimation Class\n");
	ImGui::End();

}

void GameMenu::startGameMenuPlay(std::vector<igl::opengl::ViewerCore>& core){ 
	int imageWidth = 0;
	int imageHeight = 0;
	
	ImGui::SetNextWindowPos(ImVec2(0, 0), ImGuiSetCond_FirstUseEver);
	ImGui::SetNextWindowSize(ImVec2(300, 800), ImGuiSetCond_FirstUseEver);
	
	ImGui::SetNextWindowSizeConstraints(ImVec2(325, -1.0f), ImVec2(325, -1.0f));

	ImGui::Begin("Snake Game - Animation Class", nullptr, ImGuiWindowFlags_NoMove);
	ImGui::Text(characterName);
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::ProgressBar(game->getProgress(), ImVec2(0.0f, 0.0f));
	ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
	ImGui::Text("Progress Bar");
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::ProgressBar(game->getHealth(), ImVec2(0.0f, 0.0f));
	ImGui::SameLine(0.0f, ImGui::GetStyle().ItemInnerSpacing.x);
	ImGui::Text("Health Bar");
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();

	if (ImGui::Button("Pause", ImVec2(-1, 0)))
	{
		game->setGameState(GameState::PAUSED);
	}
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	if (ImGui::Button("Back to menu", ImVec2(-1, 0)))
	{
		game->setGameState(GameState::MENU);
	}
	ImGui::Spacing();
	ImGui::Spacing();
	ImGui::Spacing();
	auto make_checkbox = [&](const char* label, unsigned int& option)
	{
		return ImGui::Checkbox(label,
			[&]() { return core[1].is_set(option); },
			[&](bool value) { return core[1].set(option, value); }
		);
	};
	if (ImGui::CollapsingHeader("Overlays", ImGuiTreeNodeFlags_DefaultOpen))
	{
		make_checkbox("Wireframe", game->data().show_lines);
		make_checkbox("Fill", game->data().show_faces);
		make_checkbox("Show texture", game->data().show_texture);
		make_checkbox("Show overlay", game->data().show_overlay);
		make_checkbox("Show overlay depth", game->data().show_overlay_depth);
	}
	ImGui::BulletText("Snake Game By Sabina & Ron Rachev\nAnimation Class\n");
	ImGui::End();
}
