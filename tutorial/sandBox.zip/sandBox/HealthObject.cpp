#include "HealthObject.h"
#include "Game.h"

HealthObject::HealthObject(float xCoordinate, float yCoordinate, float zCoordinate, int meshIdx, float speed, Game* viewer)
  : movingObject(xCoordinate,yCoordinate,zCoordinate, meshIdx, speed,viewer){
}

void HealthObject::update() {
	if (viewer->getMeshIdCollision() == meshIdx) 
		onSnakeCollide();
	else if (viewer->getTick() % 300 == 0) 
		move();
}

void  HealthObject::onSnakeCollide() {
	std::cout << " Snake Collide Health " << std::endl;;
	viewer->increaseHealth();
	viewer->resetMeshIdCollision();
	move();
}


