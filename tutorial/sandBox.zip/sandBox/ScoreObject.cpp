#include "ScoreObject.h"
#include "Game.h"

ScoreObject::ScoreObject(float xCoordinate, float yCoordinate, float zCoordinate, int meshIdx, float speed, Game* viewer)
	: movingObject(xCoordinate, yCoordinate, zCoordinate, meshIdx, speed, viewer) {

}

void ScoreObject::update() {
	if (viewer->getMeshIdCollision() == meshIdx) 
		onSnakeCollide();
	else if (viewer->getTick() % 200 == 0) 
        move();
}

void  ScoreObject::onSnakeCollide() {
	std::cout << " Snake Collide Score " << std::endl;;
	viewer->increaseProgress();
	viewer->resetMeshIdCollision();
	move();
}


