#include <irrKlang.h>
#include <string>


using namespace irrklang;

class SoundManager {
public:
	SoundManager();
	
	void playHoverMenuSound();
	void playGameSound();

	ISoundEngine * engine;

private:
	void playSound(std::string pathOfSoundFile);
};