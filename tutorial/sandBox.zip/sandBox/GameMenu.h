#pragma once
#include "igl/opengl/glfw/Viewer.h"
#include <igl/opengl/glfw/imgui/ImGuiMenu.h>
#include "Game.h"
#include <iostream>
#include <set>
class GameMenu {
public:
	GameMenu(Game* game, igl::opengl::glfw::imgui::ImGuiMenu* menu);
	void init();
	void startGameMenu(std::vector<igl::opengl::ViewerCore>& core);
	void startGameMenuPaused(std::vector<igl::opengl::ViewerCore>& core);
	void startGameMenuPlay(std::vector<igl::opengl::ViewerCore>& core);
private:
	char characterName[256] = "";
	Game* game;
	igl::opengl::glfw::imgui::ImGuiMenu* menu;
};

